|   HERLIYANSYAH       |   312010387        |
|----------------------|--------------------|
| UAS PEMROGRAMAN WEB  | GANJIL             |
|       APLIKASI IURAN KAS                  |


## LINK VIDEO DEMO WEB; https://youtu.be/kEamRU_OhXM

## LINK DEMO WEB HOSTING; https://herliyansyah27.my.id/

**Noted dan Ketentuan Program Feature;** 

* link hosting hanya berlaku satu bulan untuk masa akses 

* Untuk Menambahkan **Tambah Iuran** pada **Kas Warga** pastikan **Id** sama dengan yang ada pada **Data Warga** agar terinput dan terhapus secara otomatis bila dihapus atau tambah iuran.


**Untuk Login**

**EMAIL:** herli27052000@gmail.com 

**PASSWORD:** **herli1234** 

### Maaf jika Program belum sempurna

### Terimakasih

