<footer>
        <p>&copy; 2022  Herliyansyah  312010387  TI.20.A.2  Universitas Pelita Bangsa</p>
    </footer>
    </div>
</body>
</html>
